import bpy
import bmesh
import numpy as np

class FitnessFunctions:
    def __init__(self, decomposed_list_0, common_volume, original_volume, threshold_volume):
        self.decomposed_list_0 = decomposed_list_0
        self.common_volume = common_volume
        self.original_volume = original_volume
        self.threshold_volume = threshold_volume
        
        self.vol_of_customs = self.calculate_vol_of_customs()
        self.custom_list, self.decomposed_list = self.calculate_custom_and_decomposed_lists()

    def calculate_vol_of_customs(self):
        vol_of_customs = 0
        for obj in self.decomposed_list_0:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            volume = bm.calc_volume()
            if volume > 0 and volume < self.common_volume:
                vol_of_customs += volume
        return vol_of_customs

    def calculate_custom_and_decomposed_lists(self):
        custom_list = []
        decomposed_list = []
        for obj in self.decomposed_list_0:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            volume = bm.calc_volume()
            if volume > 0:
                decomposed_list.append(obj)
                if volume < self.threshold_volume:
                    custom_list.append(obj)
        return custom_list, decomposed_list

    def F1(self):
        return self.vol_of_customs / self.original_volume

    def F2(self):
        return len(self.custom_list) / len(self.decomposed_list)

    # ... F3, F4, ... 등의 함수 정의
